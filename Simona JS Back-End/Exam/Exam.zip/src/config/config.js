exports.SECRET = 'e4dcf4f8-35c0-424c-a03e-fc28e6b52d9b';

exports.TOKEN_KEY = 'token';